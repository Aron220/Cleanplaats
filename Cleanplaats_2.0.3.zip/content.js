/**
 * Cleanplaats - A browser extension to remove ads from Marktplaats
 * Version: 2.0.3
 */
// TODO:
// - Add functionality to let users hide Verified sellers (zakelijke verkopers is nogal lastig)

// Cross-browser compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

function getReviewCTAConfig() {
    const runtimeUrl = browserAPI?.runtime?.getURL ? browserAPI.runtime.getURL('') : '';
    const isFirefox = runtimeUrl.startsWith('moz-extension://') || navigator.userAgent.includes('Firefox');

    if (isFirefox) {
        return {
            linkLabel: 'Firefox Add-ons',
            url: 'https://addons.mozilla.org/nl/firefox/addon/cleanplaats-marktplaats-filter/reviews/'
        };
    }

    return {
        linkLabel: 'Chrome Web Store',
        url: 'https://chromewebstore.google.com/detail/cleanplaats-marktplaats-z/peebdbeclpkljmfocjifjpjlngfpfhjp/reviews'
    };
}

// State management
const CLEANPLAATS = {
    // Configuration with defaults
    settings: {
        removeTopAds: true,
        removeDagtoppers: true,
        removePromotedListings: true,
        // removeAds: true, is now always true
        removeOpvalStickers: true,
        removeReservedListings: false,
        blacklistedSellers: [],
        blacklistedTerms: [], // Added blacklisted terms
        resultsPerPage: 30, // Nieuw: aantal resultaten per pagina
        defaultSortMode: 'standard', // Nieuw: standaard sorteermodus
        sortPreferenceSource: 'cleanplaats'
    },

    // Stats tracking
    stats: {
        topAdsRemoved: 0,
        dagtoppersRemoved: 0,
        promotedListingsRemoved: 0,
        opvalStickersRemoved: 0,
        otherAdsRemoved: 0,
        totalRemoved: 0
    },

    // Runtime variables
    observers: {
        mutation: null,
        ads: null
    },

    // Feature flags
    featureFlags: {
        showStats: true,
        autoCollapse: false,
        firstRun: true
    },

    // Panel state
    panelState: {
        isCollapsed: false,
        hasShownWelcomeToast: false,
        lastSeenVersion: ''
    }
};

const CLEANPLAATS_UPDATE_NOTES = {
    '2.0.3': {
        intro: 'Cleanplaats lost problemen op met sorteren en filtert bedrijfsadvertenties nu ook  op de homepage.',
        highlights: [
            'Wisselen tussen bijvoorbeeld "Datum (nieuw-oud)" en "Prijs (laag-hoog)" werkt nu betrouwbaarder.',
            'De extensie zet je gekozen sortering niet meer onbedoeld terug bij verversen of pagineren.',
            'Daardoor hoef je een andere sorteermodus niet meer twee keer aan te klikken.',
            'De filter "Bedrijfsadvertenties" verbergt nu ook alle bedrijfs- en winkeladvertenties op de homepage bij "Voor jou" en "In je buurt", zoals bijv. Catawiki.',
            'De knop om een verkoper te verbergen blijft nu ook op mobiel zichtbaar op listingpagina’s.',
            'Bij "Beheer verborgen verkopers" kun je nu ook zelf verkopers toevoegen, inclusief meerdere namen tegelijk met komma’s of puntkomma’s.'
        ],
        note: 'Zie je nog iets vreemds met sorteren of homepage-filters? Meld het via GitHub issues in het paneel.'
    },
    '2.0.0': {
        intro: 'Deze update legt een sterkere basis voor de vernieuwde Marktplaats- en 2dehands-pagina’s.',
        highlights: [
            'De ondersteuning voor 2dehands en bijgewerkte Marktplaats-selectors is uitgebreid.',
            'Blacklist-knoppen en seller-detectie werken betrouwbaarder op meer listing-varianten.',
            'Diverse layout- en filterfixes zorgen voor stabielere opschoning van resultaten.'
        ],
        note: 'Zie je nog iets doorheen glippen? Meld het via GitHub issues in het paneel.'
    }
};

const MARKTPLAATS_SORT_LABEL_TO_MODE = {
    'standaard': 'standard',
    'datum (nieuw-oud)': 'date_new_old',
    'datum (oud-nieuw)': 'date_old_new',
    'prijs (laag-hoog)': 'price_low_high',
    'prijs (hoog-laag)': 'price_high_low',
    'afstand': 'distance'
};

function normalizeSortLabel(label) {
    return (label || '').trim().toLowerCase();
}

function getSortModeFromLabel(label) {
    return MARKTPLAATS_SORT_LABEL_TO_MODE[normalizeSortLabel(label)] || null;
}

function isMarketplaceSortDropdown(element) {
    if (!(element instanceof HTMLSelectElement)) return false;

    const ariaLabel = normalizeSortLabel(element.getAttribute('aria-label'));
    if (ariaLabel === 'sorteer op') return true;

    return Array.from(element.options || []).some(option => {
        return normalizeSortLabel(option.textContent) === 'datum (nieuw-oud)';
    });
}

function syncCleanplaatsSortMode(sortMode) {
    if (!sortMode) return;

    const modeChanged = CLEANPLAATS.settings.defaultSortMode !== sortMode;
    const sourceChanged = CLEANPLAATS.settings.sortPreferenceSource !== 'marketplace';
    if (!modeChanged && !sourceChanged) return;

    CLEANPLAATS.settings.defaultSortMode = sortMode;
    CLEANPLAATS.settings.sortPreferenceSource = 'marketplace';

    const cleanplaatsDropdown = document.getElementById('cleanplaats-sort-dropdown');
    if (cleanplaatsDropdown && cleanplaatsDropdown.value !== sortMode) {
        cleanplaatsDropdown.value = sortMode;
    }

    wakeUpBackground();
    saveSettings().catch(error => {
        console.error('Cleanplaats: Failed to sync sort mode from page selection', error);
    });
}

function setupMarketplaceSortSync() {
    if (document.body?.dataset.cleanplaatsSortSyncBound === 'true') return;
    if (document.body) {
        document.body.dataset.cleanplaatsSortSyncBound = 'true';
    }

    document.addEventListener('change', (event) => {
        const target = event.target;
        if (!isMarketplaceSortDropdown(target)) return;

        const selectedOption = target.options[target.selectedIndex];
        const sortMode = getSortModeFromLabel(selectedOption?.textContent || target.value);
        syncCleanplaatsSortMode(sortMode);
    }, true);
}

// Initialize when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCleanplaats);
} else {
    initCleanplaats();
}

/**
 * Wake up background script
 */
function wakeUpBackground() {
    try {
        browserAPI.runtime.sendMessage({ action: "keepAlive" }, (response) => {
            if (browserAPI.runtime.lastError) {
                console.log('Cleanplaats: Background script not responding, this is normal if it was sleeping');
                // Try again after a short delay
                setTimeout(() => {
                    try {
                        browserAPI.runtime.sendMessage({ action: "forceRefresh" }, () => {
                            if (!browserAPI.runtime.lastError) {
                                console.log('Cleanplaats: Background script force-refreshed successfully');
                            }
                        });
                    } catch (e) {
                        console.log('Cleanplaats: Force refresh also failed:', e);
                    }
                }, 100);
            } else {
                console.log('Cleanplaats: Background script is awake', response);
            }
        });
    } catch (error) {
        console.log('Cleanplaats: Could not wake background script:', error);
    }
}

/**
 * Set up periodic background wake-up for Firefox
 */
function setupPeriodicWakeUp() {
    // Only for Firefox (browser API exists)
    if (typeof browser !== 'undefined') {
        console.log('Cleanplaats: Setting up periodic background wake-up for Firefox');

        // Wake up background script every 30 seconds when on search pages
        setInterval(() => {
            if (isSearchResultsPage()) {
                wakeUpBackground();
            }
        }, 30000);

        // Also wake up on user activity
        ['click', 'scroll', 'keydown'].forEach(eventType => {
            document.addEventListener(eventType, () => {
                if (isSearchResultsPage()) {
                    // Debounce the wake-up calls
                    clearTimeout(window.cleanplaatsWakeUpTimeout);
                    window.cleanplaatsWakeUpTimeout = setTimeout(wakeUpBackground, 1000);
                }
            }, { passive: true });
        });
    }
}

/**
 * Main initialization function
 */
function initCleanplaats() {
    console.log('Cleanplaats: Initializing...');

    const currentVersion = getExtensionVersion();

    // Wake up background script on page load
    wakeUpBackground();

    // Set up periodic wake-up for Firefox
    setupPeriodicWakeUp();

    loadSettings()
        .then(() => {
            checkFirstRun()
                .then(isFirstRun => {
                    CLEANPLAATS.featureFlags.firstRun = isFirstRun;

                    createControlPanel();
                    setupAllObservers();
                    applySettings();
                    showOnboarding(currentVersion);

                    // Modified this part to ensure content is loaded
                    const tryCleanup = () => {
                        if (document.querySelector('.hz-Listing') || document.querySelector('#adsense-container')) {
                            performInitialCleanup();
                            injectBlacklistButtons();
                            setTimeout(checkForEmptyPage, 300);

                            // Update badge with initial count
                            setTimeout(updateStatsDisplay, 500);

                            // --- Force ad removal and layout update for Firefox ---
                            // Run multiple times to catch late-rendered ad containers
                            let attempts = 0;
                            const maxAttempts = 10;
                            const interval = setInterval(() => {
                                removePersistentGoogleAds();

                                // Also remove #banner-top-dt if present (fixes grid gap in Firefox)
                                document.querySelectorAll('#banner-top-dt').forEach(banner => {
                                    if (banner.parentNode) {
                                        banner.parentNode.removeChild(banner);
                                    }
                                });

                                // Force reflow
                                document.body.offsetHeight;
                                attempts++;
                                // Stop after a few tries or if the ad containers are gone
                                if (
                                    (!document.querySelector('#banner-right-container') && !document.querySelector('#banner-top-dt')) ||
                                    attempts >= maxAttempts
                                ) {
                                    clearInterval(interval);
                                }
                            }, 80);
                        } else {
                            setTimeout(tryCleanup, 60);
                        }
                    };
                    tryCleanup();
                });
        })
        .catch(error => {
            console.error('Cleanplaats: Initialization failed', error);
        });
}

/**
 * Check if this is the first run of the extension
 */
function checkFirstRun() {
    return new Promise(resolve => {
        browserAPI.storage.local.get('firstRun', (items) => {
            if (browserAPI.runtime.lastError) {
                console.error('Cleanplaats: Error checking first run:', browserAPI.runtime.lastError);
                resolve(true); // Default to first run on error
                return;
            }

            let isFirstRun;
            if (items.firstRun === undefined) {
                isFirstRun = true;
            } else {
                isFirstRun = items.firstRun;
            }

            // If it's the first run, set firstRun to false for next time
            if (isFirstRun) {
                browserAPI.storage.local.set({ 'firstRun': false }, () => {
                    if (browserAPI.runtime.lastError) {
                        console.error('Cleanplaats: Error setting first run flag:', browserAPI.runtime.lastError);
                    }
                    resolve(isFirstRun);
                });
            } else {
                resolve(isFirstRun);
            }
        });
    });
}

/**
 * Get the current extension version from the manifest
 */
function getExtensionVersion() {
    try {
        if (browserAPI?.runtime?.getManifest) {
            const manifest = browserAPI.runtime.getManifest();
            if (manifest && typeof manifest.version === 'string') {
                return manifest.version;
            }
        }
    } catch (error) {
        console.error('Cleanplaats: Failed to read extension version', error);
    }

    return '';
}

/**
 * Load settings from chrome.storage.local
 */
function loadSettings() {
    return new Promise((resolve, reject) => {
        browserAPI.storage.local.get(['cleanplaatsSettings', 'panelState'], (items) => {
            if (browserAPI.runtime.lastError) {
                console.error('Cleanplaats: Failed to load settings from storage', browserAPI.runtime.lastError);
                reject(browserAPI.runtime.lastError);
                return;
            }

            try {
                const storedSettings = items.cleanplaatsSettings;
                const storedPanelState = items.panelState;

                if (storedSettings) {
                    const settings = JSON.parse(storedSettings);
                    Object.assign(CLEANPLAATS.settings, settings);
                }

                if (storedPanelState) {
                    CLEANPLAATS.panelState = JSON.parse(storedPanelState);
                }

                resolve();
            } catch (error) {
                console.error('Cleanplaats: Failed to parse settings from storage', error);
                reject(error);
            }
        });
    });
}

/**
 * Save settings and panel state to chrome.storage.local
 */
function saveSettings() {
    return new Promise((resolve, reject) => {
        try {
            browserAPI.storage.local.set({
                cleanplaatsSettings: JSON.stringify(CLEANPLAATS.settings),
                panelState: JSON.stringify(CLEANPLAATS.panelState)
            }, () => {
                if (browserAPI.runtime.lastError) {
                    console.error('Cleanplaats: Failed to save settings to storage', browserAPI.runtime.lastError);
                    reject(browserAPI.runtime.lastError);
                    return;
                }
                resolve();
            });
        } catch (error) {
            console.error('Cleanplaats: Failed to save settings to storage', error);
            reject(error);
        }
    });
}

/**
 * Reset stats to zero
 */
function resetStats() {
    Object.keys(CLEANPLAATS.stats).forEach(key => {
        CLEANPLAATS.stats[key] = 0;
    });

    updateStatsDisplay();
}

/* ======================
 UI COMPONENTS
 ====================== */

/**
 * Create and append the control panel to the page
 */
function createControlPanel() {
    if (document.getElementById('cleanplaats-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'cleanplaats-panel';
    panel.className = 'cleanplaats-panel';

    if (CLEANPLAATS.featureFlags.autoCollapse || CLEANPLAATS.panelState.isCollapsed) {
        panel.classList.add('collapsed');
        panel.classList.add('collapsed-ready');
        // Set background image for minimized state (cross-browser)
        panel.style.backgroundImage = `url('${browserAPI.runtime.getURL('icons/icon128.png')}')`;
    }

    const is2dehands = location.hostname.includes('2dehands.be');
    const topAdLabel = 'Topadvertenties';
    const topAdTooltip = is2dehands
        ? "Verbergt 'Topadvertentie' en 'Topzoekertje' listings"
        : "Verwijdert betaalde 'Topadvertentie' advertenties";
    const reviewCTA = getReviewCTAConfig();

    panel.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-header" id="cleanplaats-header">
            <div class="cleanplaats-header-main">
                <h3>
                    <img id="cleanplaats-header-logo" class="cleanplaats-header-logo" alt="Cleanplaats logo" />
                    Cleanplaats
                    <span class="cleanplaats-badge" id="cleanplaats-total-count">0</span>
                </h3>
                <button id="cleanplaats-toggle" class="cleanplaats-toggle">▲</button>
            </div>
            <div class="cleanplaats-contact-grid">
                <a
                    href="https://github.com/Aron220/Cleanplaats/issues"
                    class="cleanplaats-contact cleanplaats-external-link"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open GitHub issues voor functieverzoeken, wijzigingen en bugs"
                >
                    <span class="cleanplaats-contact-icon" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.9.58.1.79-.25.79-.56v-2.17c-3.2.69-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.69-1.28-1.69-1.04-.71.08-.7.08-.7 1.15.08 1.75 1.18 1.75 1.18 1.02 1.76 2.68 1.25 3.34.95.1-.74.4-1.25.72-1.54-2.55-.29-5.23-1.28-5.23-5.69 0-1.26.45-2.28 1.18-3.08-.12-.29-.51-1.47.11-3.07 0 0 .97-.31 3.18 1.18a10.96 10.96 0 0 1 5.8 0c2.21-1.49 3.18-1.18 3.18-1.18.62 1.6.23 2.78.11 3.07.73.8 1.18 1.82 1.18 3.08 0 4.42-2.68 5.4-5.24 5.68.41.35.78 1.04.78 2.1v3.11c0 .31.21.67.8.56A11.5 11.5 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5Z"></path>
                        </svg>
                    </span>
                    <span class="cleanplaats-contact-copy">
                        <span class="cleanplaats-contact-title">Feedback</span>
                        <span class="cleanplaats-contact-text">GitHub issues</span>
                    </span>
                </a>
                <a
                    href="${reviewCTA.url}"
                    class="cleanplaats-contact cleanplaats-external-link"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Laat een review achter voor Cleanplaats op ${reviewCTA.linkLabel}"
                >
                    <span class="cleanplaats-contact-icon" aria-hidden="true">★</span>
                    <span class="cleanplaats-contact-copy">
                        <span class="cleanplaats-contact-title">Review</span>
                        <span class="cleanplaats-contact-text">${reviewCTA.linkLabel}</span>
                    </span>
                </a>
            </div>
        </div>
        <div class="cleanplaats-content">
            <div class="cleanplaats-options">
                <div class="cleanplaats-section-title">Filteropties</div>
                <div class="cleanplaats-option">
                    <label class="cleanplaats-switch">
                        <input type="checkbox" id="removeTopAds" ${CLEANPLAATS.settings.removeTopAds ? 'checked' : ''}>
                        <span class="cleanplaats-switch-slider"></span>
                    </label>
                    <label for="removeTopAds" class="cleanplaats-option-label">
                        ${topAdLabel}
                        <span class="cleanplaats-tooltip-icon" data-tooltip="${topAdTooltip}">?</span>
                    </label>
                </div>
                <div class="cleanplaats-option">
                    <label class="cleanplaats-switch">
                        <input type="checkbox" id="removeDagtoppers" ${CLEANPLAATS.settings.removeDagtoppers ? 'checked' : ''}>
                        <span class="cleanplaats-switch-slider"></span>
                    </label>
                    <label for="removeDagtoppers" class="cleanplaats-option-label">
                        Dagtoppers
                        <span class="cleanplaats-tooltip-icon" data-tooltip="Verwijdert 'Dagtopper' advertenties">?</span>
                    </label>
                </div>
                <div class="cleanplaats-option">
                    <label class="cleanplaats-switch">
                        <input type="checkbox" id="removePromotedListings" ${CLEANPLAATS.settings.removePromotedListings ? 'checked' : ''}>
                        <span class="cleanplaats-switch-slider"></span>
                    </label>
                    <label for="removePromotedListings" class="cleanplaats-option-label">
                        Bedrijfsadvertenties
                        <span class="cleanplaats-tooltip-icon" data-tooltip="Verbergt advertenties van bedrijven en winkels, zoals Catawiki, ook op de homepage bij 'Voor jou' en 'In je buurt'">?</span>
                    </label>
                </div>
                <div class="cleanplaats-option">
                    <label class="cleanplaats-switch">
                        <input type="checkbox" id="removeOpvalStickers" ${CLEANPLAATS.settings.removeOpvalStickers ? 'checked' : ''}>
                        <span class="cleanplaats-switch-slider"></span>
                    </label>
                    <label for="removeOpvalStickers" class="cleanplaats-option-label">
                        Opvalstickers
                        <span class="cleanplaats-tooltip-icon" data-tooltip="Verwijdert advertenties met opvalstickers">?</span>
                    </label>
                </div>
                <div class="cleanplaats-option">
                    <label class="cleanplaats-switch">
                        <input type="checkbox" id="removeReservedListings" ${CLEANPLAATS.settings.removeReservedListings ? 'checked' : ''}>
                        <span class="cleanplaats-switch-slider"></span>
                    </label>
                    <label for="removeReservedListings" class="cleanplaats-option-label">
                        Gereserveerde
                        <span class="cleanplaats-tooltip-icon" data-tooltip="Verbergt advertenties die 'Gereserveerd' zijn">?</span>
                    </label>
                </div>
                <div class="cleanplaats-option cleanplaats-results-dropdown-row">
                    <label for="cleanplaats-results-dropdown" class="cleanplaats-option-label" style="min-width:120px;">Resultaten per pagina:</label>
                    <select id="cleanplaats-results-dropdown" class="cleanplaats-results-dropdown">
                        <option value="30" ${CLEANPLAATS.settings.resultsPerPage == 30 ? 'selected' : ''}>30</option>
                        <option value="50" ${CLEANPLAATS.settings.resultsPerPage == 50 ? 'selected' : ''}>50</option>
                        <option value="100" ${CLEANPLAATS.settings.resultsPerPage == 100 ? 'selected' : ''}>100</option>
                    </select>
                </div>
                <div class="cleanplaats-option cleanplaats-results-dropdown-row">
                    <label for="cleanplaats-sort-dropdown" class="cleanplaats-option-label" style="min-width:120px;">Standaard sortering:</label>
                    <select id="cleanplaats-sort-dropdown" class="cleanplaats-results-dropdown">
                        <option value="standard" ${CLEANPLAATS.settings.defaultSortMode == 'standard' ? 'selected' : ''}>Standaard</option>
                        <option value="date_new_old" ${CLEANPLAATS.settings.defaultSortMode == 'date_new_old' ? 'selected' : ''}>Nieuw eerst</option>
                        <option value="date_old_new" ${CLEANPLAATS.settings.defaultSortMode == 'date_old_new' ? 'selected' : ''}>Oud eerst</option>
                        <option value="price_low_high" ${CLEANPLAATS.settings.defaultSortMode == 'price_low_high' ? 'selected' : ''}>Prijs ↑</option>
                        <option value="price_high_low" ${CLEANPLAATS.settings.defaultSortMode == 'price_high_low' ? 'selected' : ''}>Prijs ↓</option>
                        <option value="distance" ${CLEANPLAATS.settings.defaultSortMode == 'distance' ? 'selected' : ''}>Afstand</option>
                    </select>
                </div>
            </div>

            ${CLEANPLAATS.featureFlags.showStats ? `
            <div class="cleanplaats-stats cleanplaats-stats-compact" id="cleanplaats-stats">
                <div class="cleanplaats-section-title">Verwijderde items</div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Top:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-topads-count">0</span>
                </div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Dagtoppers:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-dagtoppers-count">0</span>
                </div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Bedrijf:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-promoted-count">0</span>
                </div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Stickers:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-stickers-count">0</span>
                </div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Overig:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-otherads-count">0</span>
                </div>
                <div class="cleanplaats-stat-item">
                    <span class="cleanplaats-stat-label">Totaal:</span>
                    <span class="cleanplaats-stat-value" id="cleanplaats-total-count-stats">0</span>
                </div>
            </div>
            ` : ''}

            <button id="cleanplaats-manage-terms" class="cleanplaats-button cleanplaats-blacklist-manage-btn">Beheer blacklist termen</button>
            <button id="cleanplaats-manage-blacklist" class="cleanplaats-button cleanplaats-blacklist-manage-btn">Beheer verborgen verkopers</button>
            <div id="cleanplaats-blacklist-modal" class="cleanplaats-blacklist-modal" style="display:none;"></div>
            <div id="cleanplaats-terms-modal" class="cleanplaats-terms-modal" style="display:none;"></div>

            <a
                href="https://buymeacoffee.com/cleanplaats"
                class="cleanplaats-bmc-button"
                target="_blank"
                rel="noopener"
                title="Steun Cleanplaats – Buy me a coffee!"
            >
                <span class="cleanplaats-bmc-emoji">☕</span>
                <span class="cleanplaats-bmc-text">Buy me a coffee</span>
            </a>
        </div>
    `);

    document.body.appendChild(panel);
    // Set logo src after DOM insertion to avoid DOMPurify issues
    const logoImg = panel.querySelector('#cleanplaats-header-logo');
    if (logoImg) {
        logoImg.src = browserAPI.runtime.getURL('icons/icon128.png');
    }
    panel.querySelectorAll('.cleanplaats-external-link').forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            window.open(link.href, '_blank', 'noopener,noreferrer');
        });
    });
    setupEventListeners();

    // Blacklist management button
    document.getElementById('cleanplaats-manage-blacklist').addEventListener('click', (e) => {
        e.preventDefault();
        showBlacklistModal();
    });

    // Blacklist terms management button
    document.getElementById('cleanplaats-manage-terms').addEventListener('click', (e) => {
        e.preventDefault();
        showTermsModal();
    });

    if (!document.getElementById('cleanplaats-global-tooltip')) {
        const tooltip = document.createElement('div');
        tooltip.id = 'cleanplaats-global-tooltip';
        tooltip.className = 'cleanplaats-global-tooltip';
        tooltip.style.display = 'none';
        document.body.appendChild(tooltip);
    }

    setupGlobalTooltip();
}

function setupGlobalTooltip() {
    const tooltip = document.getElementById('cleanplaats-global-tooltip');
    if (!tooltip) return;
    document.querySelectorAll('.cleanplaats-tooltip-icon').forEach(icon => {
        icon.addEventListener('mouseenter', function (e) {
            const text = icon.getAttribute('data-tooltip');
            if (!text) return;
            tooltip.textContent = text;
            tooltip.style.display = 'block';
            // Get bounding rectangles
            const rect = icon.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            // Center horizontally
            let left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
            left = Math.max(8, Math.min(left, window.innerWidth - tooltipRect.width - 8));
            // Prefer above the icon, fallback to below if not enough space
            let top = rect.top - tooltipRect.height - 8; // 8px gap above
            if (top < 8) {
                top = rect.bottom + 8; // 8px gap below
            }
            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
            tooltip.style.opacity = '1';
        });
        icon.addEventListener('mouseleave', function () {
            tooltip.style.opacity = '0';
            tooltip.style.display = 'none';
        });
    });
}

/**
 * Show the blacklist terms management modal
 */
function showTermsModal() {
    const modal = document.getElementById('cleanplaats-terms-modal');
    if (!modal) return;

    // Close the blacklist modal if it's open
    const blacklistModal = document.getElementById('cleanplaats-blacklist-modal');
    if (blacklistModal) {
        blacklistModal.style.display = 'none';
    }

    // Toggle modal visibility
    if (modal.style.display === 'block') {
        modal.style.display = 'none';
        return;
    }

    const terms = CLEANPLAATS.settings.blacklistedTerms;

    modal.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-terms-modal-content">
            <h4>Blacklist termen</h4>
            <ul id="cleanplaats-terms-list">
                ${terms.length === 0 ? '<li><em>Geen termen toegevoegd</em></li>' : terms.map(term => `
                    <li>
                        <span>${term}</span>
                        <button class="cleanplaats-unblacklist-term-btn" data-term="${term}">Verborgen</button>
                    </li>
                `).join('')}
            </ul>
            <div class="cleanplaats-terms-input-row">
                <input type="text" id="cleanplaats-term-input" class="cleanplaats-term-input" placeholder="Voer een term in">
                <button id="cleanplaats-add-term" class="cleanplaats-add-term-btn">Toevoegen</button>
            </div>
            <button id="cleanplaats-terms-close" style="margin-top:12px;">Sluiten</button>
        </div>
    `);
    modal.style.display = 'block';

    // Close modal
    document.getElementById('cleanplaats-terms-close').onclick = () => {
        modal.style.display = 'none';
    };

    // Add term logic
    const addTerm = () => {
        const input = document.getElementById('cleanplaats-term-input');
        const term = input.value.trim();
        if (term && !CLEANPLAATS.settings.blacklistedTerms.includes(term)) {
            CLEANPLAATS.settings.blacklistedTerms.push(term);
            saveSettings().then(() => {
                input.value = '';
                updateTermsModal();
                performCleanup();
                showBlacklistTermToast(term);
            });
        }
    };

    // Add term on button click
    document.getElementById('cleanplaats-add-term').onclick = addTerm;

    // Add term on Enter key
    document.getElementById('cleanplaats-term-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            addTerm();
        }
    });

    // Remove term
    setupTermsModalButtons();
}

/**
 * Update the blacklist terms modal dynamically
 */
function updateTermsModal() {
    const modal = document.getElementById('cleanplaats-terms-modal');
    if (!modal || modal.style.display === 'none') return;

    const terms = CLEANPLAATS.settings.blacklistedTerms;
    const list = document.getElementById('cleanplaats-terms-list');

    if (list) {
        list.innerHTML = DOMPurify.sanitize(
            terms.length === 0
                ? '<li><em>Geen termen toegevoegd</em></li>'
                : terms.map(term => `
                    <li>
                        <span>${term}</span>
                        <button class="cleanplaats-unblacklist-term-btn" data-term="${term}">Verborgen</button>
                    </li>
                `).join('')
        );

        setupTermsModalButtons();
    }
}

/**
 * Set up hover effects and remove functionality for terms modal buttons
 */
function setupTermsModalButtons() {
    document.querySelectorAll('.cleanplaats-unblacklist-term-btn').forEach(btn => {
        btn.onmouseover = () => {
            btn.style.background = 'green';
            btn.textContent = 'Opheffen';
        };
        btn.onmouseout = () => {
            btn.style.background = '#ff4d4d';
            btn.textContent = 'Verborgen';
        };
        btn.style.background = '#ff4d4d';
        btn.style.color = 'white';
        btn.onclick = () => {
            const term = btn.dataset.term;
            CLEANPLAATS.settings.blacklistedTerms = CLEANPLAATS.settings.blacklistedTerms.filter(t => t !== term);
            saveSettings().then(() => {
                updateTermsModal();
                unhideListingsByTerm(term);
                performCleanup();
                showUnblacklistTermToast(term);
            });
        };
    });
}

/**
 * Unhide listings that match a removed blacklist term
 */
function unhideListingsByTerm(term) {
    // Unhide .hz-Link (in je buurt tab) and .hz-Listing (normal)
    document.querySelectorAll('.hz-Link').forEach(link => {
        const titleEl = link.querySelector('.hz-StructuredListing-title, .hz-Listing-title, .hz-Listing-group--title-description, .hz-StructuredListing-body');
        if (titleEl && titleEl.textContent.toLowerCase().includes(term.toLowerCase())) {
            const listingEl = link.closest('.hz-StructuredListing') || link;
            listingEl.removeAttribute('data-cleanplaats-hidden');
            listingEl.style.display = '';
        }
    });
    document.querySelectorAll('.hz-Listing').forEach(listing => {
        const titleEl = listing.querySelector('.hz-StructuredListing-title, .hz-Listing-title, .hz-Listing-group--title-description, .hz-StructuredListing-body');
        if (titleEl && titleEl.textContent.toLowerCase().includes(term.toLowerCase())) {
            listing.removeAttribute('data-cleanplaats-hidden');
            listing.style.display = '';
        }
    });
}

/**
 * Show the onboarding notification for first-time users
 */
function showOnboarding(currentVersion = '') {
    if (CLEANPLAATS.featureFlags.firstRun) {
        if (currentVersion) {
            CLEANPLAATS.panelState.lastSeenVersion = currentVersion;
            saveSettings().catch(error => {
                console.error('Cleanplaats: Failed to store initial version state', error);
            });
        }
        showFirstTimeOnboarding();
    } else if (shouldShowUpdatePopup(currentVersion)) {
        CLEANPLAATS.panelState.lastSeenVersion = currentVersion;
        saveSettings().catch(error => {
            console.error('Cleanplaats: Failed to store seen update version', error);
        });
        showUpdatePopup(currentVersion);
    } else {
        showWelcomeToast();
    }
}

/**
 * Check whether the update popup should be shown for this version
 */
function shouldShowUpdatePopup(currentVersion) {
    if (!currentVersion) {
        return false;
    }

    return CLEANPLAATS.panelState.lastSeenVersion !== currentVersion;
}

/**
 * Show comprehensive first-time onboarding
 */
function showFirstTimeOnboarding() {
    const onboarding = document.createElement('div');
    onboarding.className = 'cleanplaats-onboarding';
    onboarding.id = 'cleanplaats-onboarding';

    onboarding.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-onboarding-content">
            <div class="cleanplaats-onboarding-header">
                <h3>🎉 Welkom bij Cleanplaats!</h3>
                <button id="cleanplaats-onboarding-close" class="cleanplaats-onboarding-close">×</button>
            </div>
            <div class="cleanplaats-onboarding-steps">
                <div class="cleanplaats-onboarding-step">
                    <span class="step-number">1</span>
                    <p>Cleanplaats verwijdert automatisch advertenties en promotionele content</p>
                </div>
                <div class="cleanplaats-onboarding-step">
                    <span class="step-number">2</span>
                    <p>Gebruik het configuratiescherm rechtsonder om de filtering aan te passen. Je opent en sluit het paneel via het pijltje bovenin.</p>
                </div>
                <div class="cleanplaats-onboarding-step">
                    <span class="step-number">3</span>
                    <p>Bekijk statistieken over verwijderde items in het configuratiescherm</p>
                </div>
            </div>
            <button id="cleanplaats-onboarding-got-it" class="cleanplaats-onboarding-button">Aan de slag!</button>
        </div>
    `);

    document.body.appendChild(onboarding);

    // Setup event listeners
    ['cleanplaats-onboarding-close', 'cleanplaats-onboarding-got-it'].forEach(id => {
        document.getElementById(id)?.addEventListener('click', () => {
            onboarding.classList.add('cleanplaats-fade-out');
            setTimeout(() => onboarding.remove(), 300);
        });
    });

    // Auto-remove after 15 seconds
    setTimeout(() => {
        if (onboarding.parentNode) {
            onboarding.classList.add('cleanplaats-fade-out');
            setTimeout(() => onboarding.remove(), 300);
        }
    }, 15000);
}

/**
 * Show a "Wat is er nieuw" popup for updated versions
 */
function showUpdatePopup(version) {
    const existingPopup = document.getElementById('cleanplaats-update-popup');
    if (existingPopup) {
        existingPopup.remove();
    }

    const updateContent = CLEANPLAATS_UPDATE_NOTES[version] || {
        intro: 'Cleanplaats heeft een nieuwe update gekregen met verbeteringen en onderhoud aan de extensie.',
        highlights: [
            'Diverse verbeteringen en fixes voor de huidige resultaatpagina’s.',
            'Kleine verfijningen aan het paneel en de filtering.',
            'Onderhoudswerk om Cleanplaats stabiel te houden op nieuwe sitewijzigingen.'
        ],
        note: 'Zie je een probleem of heb je een idee? Gebruik de GitHub-link in het paneel.'
    };

    const popup = document.createElement('div');
    popup.className = 'cleanplaats-info-overlay cleanplaats-info-overlay--visible';
    popup.id = 'cleanplaats-update-popup';
    popup.setAttribute('role', 'dialog');
    popup.setAttribute('aria-modal', 'true');
    popup.setAttribute('aria-hidden', 'false');

    const stepsMarkup = updateContent.highlights
        .map(step => `<li>${step}</li>`)
        .join('');

    popup.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-info-card">
            <div class="cleanplaats-info-header">
                <img id="cleanplaats-update-popup-logo" class="cleanplaats-info-logo" alt="Cleanplaats">
                <span class="cleanplaats-info-eyebrow">Nieuwe update</span>
                <h3 class="cleanplaats-info-title">Wat is er nieuw? (${version})</h3>
                <p class="cleanplaats-info-intro">${updateContent.intro}</p>
            </div>
            <ol class="cleanplaats-info-steps">${stepsMarkup}</ol>
            <p class="cleanplaats-info-note">${updateContent.note}</p>
            <div class="cleanplaats-info-footer">
                <button type="button" id="cleanplaats-update-popup-close" class="cleanplaats-info-button">Top, bedankt</button>
            </div>
        </div>
    `);

    const closePopup = () => {
        popup.classList.remove('cleanplaats-info-overlay--visible');
        popup.setAttribute('aria-hidden', 'true');
        setTimeout(() => popup.remove(), 200);
        document.removeEventListener('keydown', handleKeydown);
    };

    const handleKeydown = (event) => {
        if (event.key === 'Escape') {
            closePopup();
        }
    };

    popup.addEventListener('click', (event) => {
        if (event.target === popup) {
            closePopup();
        }
    });

    document.addEventListener('keydown', handleKeydown);
    document.body.appendChild(popup);
    const popupLogo = document.getElementById('cleanplaats-update-popup-logo');
    if (popupLogo) {
        popupLogo.src = browserAPI.runtime.getURL('icons/icon128.png');
    }
    document.getElementById('cleanplaats-update-popup-close')?.addEventListener('click', closePopup);
}

/**
 * Show welcome toast for returning users
 */
function showWelcomeToast() {
    // Only show on main page and if not already shown
    if (CLEANPLAATS.panelState.hasShownWelcomeToast ||
        location.pathname !== '/' ||
        location.hostname !== 'www.marktplaats.nl') {
        return;
    }

    const toast = document.createElement('div');
    toast.className = 'cleanplaats-toast';
    toast.id = 'cleanplaats-toast';

    // Add removed count if available
    const totalRemoved = CLEANPLAATS.stats.totalRemoved;
    const message = totalRemoved > 0
        ? `Cleanplaats is actief (${totalRemoved} items verwijderd)`
        : 'Cleanplaats is actief';

    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-toast-content">
            <span class="cleanplaats-toast-icon">✨</span>
            <span class="cleanplaats-toast-message">${message}</span>
        </div>
    `);

    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('visible'), 100);
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);

    // Mark as shown
    CLEANPLAATS.panelState.hasShownWelcomeToast = true;
}

/**
 * Show notification about empty page
 */
let notificationTimeout; // To store the timeout ID
let notificationVisible = false; // Flag to track if the notification is currently visible

/**
 * Check if the page is empty or has few listings
 */
function checkForEmptyPage() {
    clearTimeout(notificationTimeout);

    // Increase the delay to ensure all cleanups are complete
    notificationTimeout = setTimeout(() => {
        // Force a final check of all elements that should be hidden
        performCleanup();

        // Now check the final state
        const visibleListings = document.querySelectorAll('.hz-Listing:not([data-cleanplaats-hidden])');
        const totalListings = document.querySelectorAll('.hz-Listing');
        const hiddenCount = totalListings.length - visibleListings.length;

        // Only show notification if we actually removed something
        if (hiddenCount === 0) return;

        // Clear any existing notifications first
        clearAllNotifications();

        if (visibleListings.length === 0) {
            showBubbleNotification('De pagina is leeg omdat deze helemaal uit advertenties bestond! Probeer een volgende pagina of wijzig de filters.');
        } else if (visibleListings.length < 5) {
            const listingWord = visibleListings.length === 1 ? 'resultaat' : 'resultaten';
            const removedWord = hiddenCount === 1 ? 'advertentie' : 'advertenties';
            showBubbleNotification(`Er ${visibleListings.length === 1 ? 'is' : 'zijn'} nog ${visibleListings.length} ${listingWord} over nadat Cleanplaats ${hiddenCount} ${removedWord} heeft verwijderd.`);
        }
    }, 1000); // Increased from 500ms to 1000ms
}

/**
 * Show a toast notification
 */
function showBubbleNotification(message) {
    let toast = document.getElementById('cleanplaats-bubble-notification');

    if (toast) {
        // If a toast is already visible, update its message
        const messageElement = toast.querySelector('.cleanplaats-toast-message span');
        if (messageElement) {
            messageElement.textContent = message;
        }
    } else {
        // If no toast is visible, create a new one
        toast = document.createElement('div');
        toast.className = 'cleanplaats-blacklist-toast';
        toast.id = 'cleanplaats-bubble-notification'; // Add an ID to find it later

        toast.innerHTML = DOMPurify.sanitize(`
            <div class="cleanplaats-blacklist-toast-content">
                <span class="cleanplaats-toast-icon">✨</span>
                <div class="cleanplaats-toast-message">
                    <span>${message}</span>
                </div>
            </div>
        `);

        document.body.appendChild(toast);
        setTimeout(() => requestAnimationFrame(() => toast.classList.add('visible')), 0);
    }

    // Clear any existing timeout
    if (toast.timeoutId) {
        clearTimeout(toast.timeoutId);
    }

    // Set a new timeout
    toast.timeoutId = setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => {
            if (toast) {
                toast.remove();
            }
        }, 300);
    }, 5000);
}

/**
 * Clear all Cleanplaats notifications
 */
function clearAllNotifications() {
    const notifications = document.querySelectorAll('[id^="cleanplaats-"]');
    notifications.forEach(notification => {
        if (notification.classList.contains('cleanplaats-empty-notification') ||
            notification.id === 'cleanplaats-loading') {
            notification.remove();
        }
    });
    notificationVisible = false;
}

/**
 * Clear the bubble notification
 */
function clearBubbleNotification() {
    const toast = document.getElementById('cleanplaats-bubble-notification');
    if (toast) {
        toast.classList.remove('visible');
        setTimeout(() => {
            if (toast) {
                toast.remove();
            }
        }, 300);
    }
}

/**
 * Set up all event listeners for the control panel
 */
function setupEventListeners() {
    // Panel toggle
    const panel = document.getElementById('cleanplaats-panel'); // Target the panel
    const toggle = document.getElementById('cleanplaats-toggle'); // Chevron button

    if (panel) { // Listen on the panel itself
        panel.addEventListener('click', (e) => {
            // Block toggling while animating
            if (panel.classList.contains('animating')) {
                // Optionally, you could log or provide feedback here
                return;
            }

            const isPanelCollapsed = panel.classList.contains('collapsed');
            let canToggle = false;

            // Determine if the click should trigger a toggle
            if (isPanelCollapsed) {
                // If collapsed (icon mode), any click directly on the panel/icon should expand it.
                if (e.target === panel) {
                    canToggle = true;
                }
            } else {
                // If expanded, toggle only if the click is on the header area,
                // but not on other specific interactive elements (inputs, buttons, links, tooltips, switches).
                const header = document.getElementById('cleanplaats-header');
                if (header && header.contains(e.target)) { // Click is within the header
                    if (
                        e.target.id === 'cleanplaats-toggle' ||
                        !e.target.closest('input, button, a, .cleanplaats-tooltip, .cleanplaats-switch')
                    ) {
                        canToggle = true;
                    }
                }
            }

            if (canToggle) {
                e.preventDefault(); // Prevent default action if 'a' tag was somehow involved in header
                e.stopPropagation(); // Stop event from bubbling further

                // Close any open modals before toggling panel
                const blacklistModal = document.getElementById('cleanplaats-blacklist-modal');
                const termsModal = document.getElementById('cleanplaats-terms-modal');
                if (blacklistModal && blacklistModal.style.display === 'block') {
                    blacklistModal.style.display = 'none';
                }
                if (termsModal && termsModal.style.display === 'block') {
                    termsModal.style.display = 'none';
                }

                // --- Begin new logic for collapsed-ready and animating ---
                // Remove collapsed-ready immediately before any toggle
                panel.classList.remove('collapsed-ready');
                // Remove background image when not collapsed-ready
                panel.style.backgroundImage = '';
                // Add animating class before starting transition
                panel.classList.add('animating');

                CLEANPLAATS.panelState.isCollapsed = !CLEANPLAATS.panelState.isCollapsed;
                panel.classList.toggle('collapsed', CLEANPLAATS.panelState.isCollapsed);

                if (toggle) {
                    toggle.textContent = CLEANPLAATS.panelState.isCollapsed ? '▲' : '▼';
                }

                // Fallback timeout in case transitionend is missed
                let fallbackTimeout = setTimeout(() => {
                    panel.classList.remove('animating');
                    if (CLEANPLAATS.panelState.isCollapsed) {
                        panel.classList.add('collapsed-ready');
                        // Set background image for minimized state (cross-browser)
                        panel.style.backgroundImage = `url('${browserAPI.runtime.getURL('icons/icon128.png')}')`;
                    }
                }, 600); // Slightly longer than the longest transition (0.4s)

                // If collapsing, add collapsed-ready after width transition, remove animating after width transition
                // If expanding, remove animating after max-height transition
                const onTransitionEnd = (event) => {
                    if (CLEANPLAATS.panelState.isCollapsed && event.propertyName === 'width') {
                        panel.classList.add('collapsed-ready');
                        // Set background image for minimized state (cross-browser)
                        panel.style.backgroundImage = `url('${browserAPI.runtime.getURL('icons/icon128.png')}')`;
                        panel.classList.remove('animating');
                        panel.removeEventListener('transitionend', onTransitionEnd);
                        clearTimeout(fallbackTimeout);
                    } else if (!CLEANPLAATS.panelState.isCollapsed && event.propertyName === 'max-height') {
                        panel.classList.remove('animating');
                        // Remove background image when expanded
                        panel.style.backgroundImage = '';
                        panel.removeEventListener('transitionend', onTransitionEnd);
                        clearTimeout(fallbackTimeout);
                    }
                };
                panel.addEventListener('transitionend', onTransitionEnd);

                saveSettings();
            }
        });
    }

    // Setup checkbox change listeners
    ['removeTopAds', 'removeDagtoppers', 'removePromotedListings',
        'removeOpvalStickers', 'removeReservedListings'].forEach(id => {
            const checkbox = document.getElementById(id);
            if (checkbox) {
                checkbox.addEventListener('change', handleCheckboxChange);
            }
        });

    // Setup results dropdown listener
    setupResultsDropdownListener();

    // Setup sort dropdown listener
    setupSortDropdownListener();

    // Sync the Cleanplaats sort preference when the native page sort changes
    setupMarketplaceSortSync();
}

/**
 * Handle checkbox change events
 */
function handleCheckboxChange(event) {
    const setting = event.target.id;
    const value = event.target.checked;

    // Update state
    CLEANPLAATS.settings[setting] = value;

    // Save settings and apply changes immediately
    saveSettings()
        .then(() => {
            // Reset previous changes and reapply filters
            resetPreviousChanges();
            performCleanup();

            // Clear the bubble notification
            clearBubbleNotification();

            // Show feedback in header
            const header = document.querySelector('.cleanplaats-header');
            const feedback = document.createElement('div');
            feedback.className = 'cleanplaats-feedback';
            feedback.textContent = '✓';

            // Remove any existing feedback
            header.querySelectorAll('.cleanplaats-feedback').forEach(el => el.remove());

            header.appendChild(feedback);
            requestAnimationFrame(() => feedback.classList.add('cleanplaats-feedback-show'));

            // Remove after animation
            setTimeout(() => feedback.remove(), 1500);

            // Check for empty page after applying filters
            checkForEmptyPage();

            // Update badge immediately after applying filters
            updateStatsDisplay();
        })
        .catch(error => {
            console.error('Cleanplaats: Failed to apply setting', error);
            event.target.checked = !value;
        });
}

/**
 * Apply current settings and update the UI
 */
function applySettings() {
    saveSettings()
        .then(() => {
            resetPreviousChanges();
            performCleanup();
        })
        .catch(error => {
            console.error('Cleanplaats: Failed to apply settings', error);
        });
}

/**
 * Update the stats display in the UI
 */
function updateStatsDisplay() {
    if (!CLEANPLAATS.featureFlags.showStats) return;

    const stats = CLEANPLAATS.stats;

    // Update individual stat counts
    updateElementText('cleanplaats-topads-count', stats.topAdsRemoved);
    updateElementText('cleanplaats-dagtoppers-count', stats.dagtoppersRemoved);
    updateElementText('cleanplaats-promoted-count', stats.promotedListingsRemoved);
    updateElementText('cleanplaats-stickers-count', stats.opvalStickersRemoved);
    updateElementText('cleanplaats-otherads-count', stats.otherAdsRemoved);

    // Calculate and update total count
    const total = stats.topAdsRemoved + stats.dagtoppersRemoved + stats.promotedListingsRemoved + stats.opvalStickersRemoved + stats.otherAdsRemoved;
    stats.totalRemoved = total;

    updateElementText('cleanplaats-total-count-stats', total);
    updateElementText('cleanplaats-total-count', total);
}

/**
 * Helper to update element text content if the element exists
 */
function updateElementText(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

/* ======================
 CORE CLEANUP FUNCTIONALITY
 ====================== */

/**
 * Perform initial cleanup on page load
 */
function performInitialCleanup() {
    try {
        performCleanup();
        // No need to remove #banner-top-dt-container here, it's handled in removePersistentGoogleAds
    } catch (error) {
        console.error('Cleanplaats: Initial cleanup failed', error);
    }
}

/**
 * Main cleanup function that handles all types of content removal
 */
function performCleanup() {
    // Always remove regular ads first
    removeAllAds();
    removePersistentGoogleAds();

    // Then handle optional filters
    if (CLEANPLAATS.settings.removeTopAds) removeTopAdvertisements();
    if (CLEANPLAATS.settings.removeDagtoppers) removeDagtoppers();
    if (CLEANPLAATS.settings.removePromotedListings) removePromotedListings();
    if (CLEANPLAATS.settings.removeOpvalStickers) removeOpvalStickerListings();
    if (CLEANPLAATS.settings.removeReservedListings) removeReservedListings();

    // Handle blacklisted sellers
    document.querySelectorAll('.hz-Listing').forEach(listing => {
        const sellerNameEl = listing.querySelector('.hz-Listing-seller-name, .hz-Listing-seller-name-new, .hz-Listing-seller-link, .hz-Listing-sellerName, .hz-Listing-sellerName-new');
        if (!sellerNameEl) return;
        const sellerName = sellerNameEl.textContent.trim();
        if (CLEANPLAATS.settings.blacklistedSellers.includes(sellerName)) {
            listing.setAttribute('data-cleanplaats-hidden', 'true');
            listing.style.display = 'none';
        }
    });

    // Handle blacklisted terms in titles
    // For "in je buurt" tab: hide the <a.hz-Link> if the title matches
    document.querySelectorAll('.hz-Link').forEach(link => {
        const titleEl = link.querySelector('.hz-StructuredListing-title, .hz-Listing-title, .hz-Listing-group--title-description, .hz-StructuredListing-body');
        if (!titleEl) return;
        const title = titleEl.textContent.trim().toLowerCase();
        CLEANPLAATS.settings.blacklistedTerms.forEach(term => {
            if (title.includes(term.toLowerCase())) {
                const listingEl = link.closest('.hz-StructuredListing') || link;
                listingEl.setAttribute('data-cleanplaats-hidden', 'true');
                listingEl.style.display = 'none';
            }
        });
    });
    // For normal listings: hide the .hz-Listing
    document.querySelectorAll('.hz-Listing').forEach(listing => {
        const titleEl = listing.querySelector('.hz-StructuredListing-title, .hz-Listing-title, .hz-Listing-group--title-description, .hz-StructuredListing-body');
        if (!titleEl) return;
        const title = titleEl.textContent.trim().toLowerCase();
        CLEANPLAATS.settings.blacklistedTerms.forEach(term => {
            if (title.includes(term.toLowerCase())) {
                listing.setAttribute('data-cleanplaats-hidden', 'true');
                listing.style.display = 'none';
            }
        });
    });

    updateStatsDisplay();
}

/**
 * Reset previous changes made by the extension
 */
function resetPreviousChanges() {
    resetStats();

    document.querySelectorAll('[data-cleanplaats-hidden]').forEach(el => {
        try {
            el.style.cssText = el.getAttribute('data-original-style') || '';
            el.removeAttribute('data-cleanplaats-hidden');
            el.removeAttribute('data-original-style');
        } catch (error) {
            console.error('Cleanplaats: Error restoring element', error);
        }
    });
}

/* ======================
 AD REMOVAL FUNCTIONS
 ====================== */

/**
 * Remove top advertisements
 */
function removeTopAdvertisements() {
    const is2dehands = location.hostname.includes('2dehands.be');
    const labels = is2dehands ? ['Topzoekertje', 'Topadvertentie'] : ['Topadvertentie'];
    const priorityBadgeSelector = [
        '.hz-Listing-priority span',
        '.hz-Listing-priority-new',
        '[class*="hz-Listing-priority-new"]'
    ].join(', ');
    const removedCount = labels.reduce((total, label) => {
        return total + findAndHideListings(priorityBadgeSelector, label);
    }, 0);
    CLEANPLAATS.stats.topAdsRemoved += removedCount;
}

/**
 * Remove dagtoppers
 */
function removeDagtoppers() {
    const priorityBadgeSelector = [
        '.hz-Listing-priority span',
        '.hz-Listing-priority-new',
        '[class*="hz-Listing-priority-new"]'
    ].join(', ');
    const removedCount = findAndHideListings(priorityBadgeSelector, 'Dagtopper');
    CLEANPLAATS.stats.dagtoppersRemoved += removedCount;
}

/**
 * Remove promoted listings with "Bezoek website" links
 */
function removePromotedListings() {
    let count = 0;

    // Check both regular listings and car listings
    const selectors = [
        '.hz-Listing-seller-link',           // Regular listings
        '.hz-Listing-seller-external-link'   // Car listings
    ];

    selectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(sellerLink => {
            try {
                const hasVisitWebsite = Array.from(sellerLink.querySelectorAll('span, a'))
                    .some(el => el.textContent?.trim() === 'Bezoek website');

                if (hasVisitWebsite) {
                    const listing = sellerLink.closest('.hz-Listing');
                    if (listing && !listing.hasAttribute('data-cleanplaats-hidden') && hideElement(listing)) {
                        count++;
                    }
                }
            } catch (error) {
                console.error('Cleanplaats: Error processing promoted listing', error);
            }
        });
    });

    document.querySelectorAll('.hz-StructuredListing').forEach(listing => {
        try {
            if (listing.hasAttribute('data-cleanplaats-hidden') || !isHomepagePartnerListing(listing)) {
                return;
            }

            if (hideElement(listing)) {
                count++;
            }
        } catch (error) {
            console.error('Cleanplaats: Error processing homepage partner listing', error);
        }
    });

    CLEANPLAATS.stats.promotedListingsRemoved += count;
}

function isHomepagePartnerListing(listing) {
    const hrefs = Array.from(listing.querySelectorAll('a[href]'))
        .map(link => link.href || link.getAttribute('href') || '')
        .filter(Boolean);

    return hrefs.some(href => /\/a\d+(?:[-/?]|$)/i.test(href));
}

/**
 * Remove listings with promotional stickers
 */
function removeOpvalStickerListings() {
    let count = 0;
    const stickerSelectors = [
        '.hz-Listing-Opvalsticker-wrapper, .hz-Listing-Opvalsticker-wrapper-new',
        '[data-testid="listing-opval-sticker"]'
    ];

    stickerSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(sticker => {
            try {
                const listing = sticker.closest('.hz-Listing');
                if (listing && !listing.hasAttribute('data-cleanplaats-hidden') && hideElement(listing)) {
                    count++;
                }
            } catch (error) {
                console.error('Cleanplaats: Error processing sticker listing', error);
            }
        });
    });

    CLEANPLAATS.stats.opvalStickersRemoved += count;
}

/**
 * Remove listings that are marked as reserved (price label 'Gereserveerd')
 */
function removeReservedListings() {
    const count = findAndHideListings('.hz-Listing-price', 'Gereserveerd');
    CLEANPLAATS.stats.otherAdsRemoved += count;
}

/**
 * Remove all other ads (banners, Google ads, etc.)
 */
function removeAllAds() {
    let count = 0;

    function safeHide(selector) {
        try {
            const elements = document.querySelectorAll(selector);
            elements.forEach(el => {
                // First hide the element itself
                if (!el.hasAttribute('data-cleanplaats-hidden') && hideElement(el)) {
                    count++;
                }

                // Also hide the parent li if it's a banner container
                const parentLi = el.closest('li.bannerContainerLoading');
                if (parentLi && !parentLi.hasAttribute('data-cleanplaats-hidden')) {
                    hideElement(parentLi);
                }

                // Hide feed banner wrappers to avoid grid gaps
                const feedBanner = el.closest('.hz-FeedBannerBlock, .Banners-bannerFeedItem');
                if (feedBanner && !feedBanner.hasAttribute('data-cleanplaats-hidden')) {
                    hideElement(feedBanner);
                }
            });
        } catch (error) {
            console.log('Cleanplaats: Error hiding ads', error);
        }
    }

    // First handle homepage ads with overlay label
    document.querySelectorAll('.hz-Listing-imageOverlayLabel').forEach(overlay => {
        if (overlay.textContent.trim() === 'Homepagina-advertentie') {
            const link = overlay.closest('.hz-Link.hz-Link--block');
            if (link && !link.hasAttribute('data-cleanplaats-hidden')) {
                hideElement(link);
                count++;
            }
        }
    });

    const adSelectors = [
        '#adsense-container',
        '#adsense-container-bottom-lazy',
        '#adBlock',
        '.hz-Banner',
        '.hz-Banner--fluid',
        '#banner-rubrieks-dt',
        '#banner-top-dt',
        '#banner-top-dt-container',
        '[data-google-query-id]',
        '[id*="google_ads_iframe"]',
        '[id*="google_ads_top_frame"]',
        '[aria-label="Advertisement"]',
        '[title="3rd party ad content"]',
        '.i_.div',
        '[data-ad-container]',
        '[data-bg="true"]',
        '[class*="adsbygoogle"]',
        'ins.adsbygoogle',
        'iframe[src*="googleads"]',
        'iframe[src*="doubleclick"]',
        '[id*="div-gpt-ad"]',
        '.hz-Listings__container--cas[data-testid="BottomBlockLazyListings"]',
        '[class*="creative"]',
        '#google_ads_top_frame',
        '.creative',
        'li.bannerContainerLoading', // Added this line to directly target the container
        '.bannerContainerLoading', // Added this as a fallback
        '.bannerContainerLoading .hz-Banner', // Added this to target banners inside containers
        '.bannerContainerLoading .hz-Banner--fluid' // Added this to target fluid banners
    ];

    adSelectors.forEach(selector => {
        safeHide(selector);
    });

    CLEANPLAATS.stats.otherAdsRemoved += count;
}

/**
 * Remove persistent Google ads and empty ad containers that resist normal hiding.
 * This is called on every cleanup and navigation, so grid gaps are always collapsed.
 */
function removePersistentGoogleAds() {
    let count = 0;
    // Remove large ad containers in the grid (e.g. in je buurt tab)
    document.querySelectorAll('.creative, div[id^="google_ads_iframe"], div[data-google-query-id], div[aria-label="Advertisement"]').forEach(ad => {
        try {
            const gridItem = ad.closest('.hz-Link.hz-Link--block');
            if (gridItem && gridItem.parentNode) {
                gridItem.parentNode.removeChild(gridItem);
                count++;
                return;
            }
            if (ad.parentNode) {
                ad.parentNode.removeChild(ad);
                count++;
            }
        } catch (error) {
            console.error('Cleanplaats: Error removing persistent ad', error);
        }
    });

    // Remove banner-right-container and its children (fix grid gap)
    document.querySelectorAll('#banner-right-container').forEach(banner => {
        if (banner.parentNode) {
            banner.parentNode.removeChild(banner);
            count++;
        }
    });

    // Remove #banner-top-dt-container (and its children) if present (fixes grid gap instantly on tab switch)
    document.querySelectorAll('#banner-top-dt-container').forEach(container => {
        if (container.parentNode) {
            container.parentNode.removeChild(container);
            count++;
        }
    });

    // Remove empty banner containers that cause grid gaps
    document.querySelectorAll('.hz-FeedBannerBlock, .Banners-bannerFeedItem').forEach(banner => {
        if (
            banner.childElementCount === 0 ||
            Array.from(banner.children).every(child => child.offsetParent === null)
        ) {
            if (banner.parentNode) {
                banner.parentNode.removeChild(banner);
                count++;
            }
        }
    });

    CLEANPLAATS.stats.otherAdsRemoved += count;
}

/**
 * Helper to find and hide elements with specific text content
 */
function findAndHideListings(selector, textContent) {
    let count = 0;

    try {
        document.querySelectorAll(selector).forEach(el => {
            if (el.textContent?.trim() === textContent) {
                const listing = el.closest('.hz-Listing');
                if (listing && !listing.hasAttribute('data-cleanplaats-hidden') && hideElement(listing)) {
                    count++;
                }
            }
        });
    } catch (error) {
        console.error(`Cleanplaats: Error finding "${textContent}" listings`, error);
    }

    return count;
}

/**
 * Helper to hide an element and mark it
 */
function hideElement(element) {
    if (!element || element.hasAttribute('data-cleanplaats-hidden')) {
        return false;
    }

    try {
        // Store original style
        element.setAttribute('data-original-style', element.style.cssText);

        // Hide the element
        element.setAttribute('data-cleanplaats-hidden', 'true');
        element.style.display = 'none !important';

        return true;
    } catch (error) {
        console.error('Cleanplaats: Error hiding element', error);
        return false;
    }
}

/* ======================
 BLACKLIST MANAGEMENT
 ====================== */

/**
 * Add a seller to the blacklist
 */
function addSellerToBlacklist(sellerName) {
    addSellersToBlacklist([sellerName]);
}

/**
 * Add one or more sellers to the blacklist
 */
function addSellersToBlacklist(sellerNames) {
    const normalizedSellerNames = sellerNames
        .map(name => name.trim())
        .filter(Boolean)
        .filter((name, index, arr) => arr.indexOf(name) === index)
        .filter(name => !CLEANPLAATS.settings.blacklistedSellers.includes(name));

    if (normalizedSellerNames.length === 0) return;

    CLEANPLAATS.settings.blacklistedSellers.push(...normalizedSellerNames);
    saveSettings().then(() => {
        performCleanup();
        injectBlacklistButtons();
        updateBlacklistModal();

        if (normalizedSellerNames.length === 1) {
            showBlacklistToast(normalizedSellerNames[0]);
            return;
        }

        showBulkBlacklistToast(normalizedSellerNames.length);
    });
}

/**
 * Show a toast notification for blacklisting
 */
function showBlacklistToast(sellerName) {
    const toast = document.createElement('div');
    toast.className = 'cleanplaats-blacklist-toast';

    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-toast-content">
            <span class="cleanplaats-toast-icon eye">👁</span>
            <div class="cleanplaats-toast-message">
                <strong>${sellerName} verborgen</strong>
                <span>Beheer verborgen verkopers via het paneel</span>
            </div>
        </div>
    `);

    document.body.appendChild(toast);
    // Add a small delay before adding the 'visible' class
    setTimeout(() => {
        requestAnimationFrame(() => toast.classList.add('visible'));
    }, 50);

    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Show a toast notification for blacklisting multiple sellers
 */
function showBulkBlacklistToast(count) {
    const toast = document.createElement('div');
    toast.className = 'cleanplaats-blacklist-toast';

    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-toast-content">
            <span class="cleanplaats-toast-icon eye">👁</span>
            <div class="cleanplaats-toast-message">
                <strong>${count} verkopers verborgen</strong>
                <span>Beheer verborgen verkopers via het paneel</span>
            </div>
        </div>
    `);

    document.body.appendChild(toast);
    setTimeout(() => {
        requestAnimationFrame(() => toast.classList.add('visible'));
    }, 50);

    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Show a toast notification for unblacklisting
 */
function showUnblacklistToast(sellerName) {
    const toast = document.createElement('div');
    toast.className = 'cleanplaats-blacklist-toast';

    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-toast-content">
            <span class="cleanplaats-toast-icon eye">👁</span>
            <div class="cleanplaats-toast-message">
                <strong>${sellerName} niet meer verborgen</strong>
                <span>Deze verkoper is weer zichtbaar in de resultaten</span>
            </div>
        </div>
    `);

    document.body.appendChild(toast);
    // Add a small delay before adding the 'visible' class
    setTimeout(() => {
        requestAnimationFrame(() => toast.classList.add('visible'));
    }, 50);

    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Remove a seller from the blacklist
 */
function removeSellerFromBlacklist(sellerName) {
    CLEANPLAATS.settings.blacklistedSellers = CLEANPLAATS.settings.blacklistedSellers.filter(s => s !== sellerName);
    saveSettings().then(() => {
        // Show all listings from this seller immediately
        document.querySelectorAll('.hz-Listing').forEach(listing => {
            const sellerNameEl = listing.querySelector('.hz-Listing-seller-name, .hz-Listing-seller-name-new, .hz-Listing-seller-link, .hz-Listing-sellerName, .hz-Listing-sellerName-new');
            if (!sellerNameEl) return;
            if (sellerNameEl.textContent.trim() === sellerName) {
                listing.removeAttribute('data-cleanplaats-hidden');
                listing.style.display = '';
            }
        });
        performCleanup();
        injectBlacklistButtons();
        updateBlacklistModal(); // Update modal dynamically
    });
}

/**
 * Inject blacklist buttons under seller names
 */
function injectBlacklistButtons() {
    document.querySelectorAll('.hz-Listing').forEach(listing => {
        const oldBtn = listing.querySelector('.cleanplaats-blacklist-btn-row');
        const oldTopRight = listing.querySelector('.cleanplaats-seller-topright-mobile');
        const oldInlineBtn = listing.querySelector('.cleanplaats-inline-btn');

        // Try to find seller name using different structures
        let sellerName = listing.dataset.cleanplaatsSellerName || null;
        let sellerElement = null;
        let isCarAdvert = false;

        // First try car advert structure (.hz-Listing-sellerName)
        const carSellerElement = listing.querySelector('.hz-Listing-sellerName, .hz-Listing-sellerName-new');
        if (carSellerElement) {
            sellerName = carSellerElement.textContent.trim();
            sellerElement = carSellerElement;
            isCarAdvert = true;
        } else {
            // Normal advert structure: rely on stable seller-name classes.
            // Marktplaats now often wraps these in CSS-module container classes.
            const sellerNameEl = listing.querySelector('.hz-Listing-seller-name, .hz-Listing-seller-name-new');
            if (sellerNameEl) {
                sellerName = sellerNameEl.textContent.trim();
                const sellerLink = sellerNameEl.closest('a');
                sellerElement = sellerLink ? (sellerLink.parentElement || sellerLink) : sellerNameEl;
                isCarAdvert = false;
            }
        }

        if (sellerName) {
            listing.dataset.cleanplaatsSellerName = sellerName;
        }

        if (!sellerName) return;

        // Hide if already blacklisted
        if (CLEANPLAATS.settings.blacklistedSellers.includes(sellerName)) {
            listing.setAttribute('data-cleanplaats-hidden', 'true');
            listing.style.display = 'none';
            return;
        }

        // --- MOBILE ONLY: Seller + hide button in top right ---
        if (window.innerWidth < 700) {
            if (oldTopRight && oldTopRight.dataset.cleanplaatsSellerName === sellerName) {
                return;
            }

            // Remove any desktop buttons before inserting the mobile row.
            if (oldBtn) oldBtn.remove();
            if (oldInlineBtn) oldInlineBtn.remove();
            if (oldTopRight) oldTopRight.remove();

            // Create the top row container
            const topRow = document.createElement('div');
            topRow.className = 'cleanplaats-seller-topright-mobile';
            topRow.dataset.cleanplaatsSellerName = sellerName;
            topRow.innerHTML = DOMPurify.sanitize(`
                <span class="cleanplaats-seller-name-mobile">${sellerName}</span>
                <button class="cleanplaats-blacklist-btn-mobile" title="Verberg deze verkoper" aria-label="Verberg deze verkoper">
                  <svg xmlns="http://www.w3.org/2000/svg" height="18" width="18" viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17.94 17.94A10.06 10.06 0 0 1 12 20C7 20 2.73 16.11 1 12c.74-1.61 1.81-3.09 3.06-4.31"/>
                    <path d="M22.54 12.88A10.06 10.06 0 0 0 12 4c-1.61 0-3.16.31-4.59.88"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                </button>
            `);
            // Insert as first child of the main content column
            const content = listing.querySelector('.hz-Listing-listview-content, .hz-Listing-listview-content-new');
            if (content && content.firstChild) {
                content.insertBefore(topRow, content.firstChild);
            } else if (content) {
                content.appendChild(topRow);
            }
            // Add click handler
            topRow.querySelector('.cleanplaats-blacklist-btn-mobile').onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (confirm(`Wil je alle advertenties van ${sellerName} verbergen?`)) {
                    addSellerToBlacklist(sellerName);
                }
            };
            // Do NOT inject the desktop button on mobile
            return;
        }

        if (!sellerElement) return;

        // Remove any existing button to avoid duplicates now that we know we can rebuild.
        if (oldBtn) oldBtn.remove();
        if (oldTopRight) oldTopRight.remove();
        if (oldInlineBtn) oldInlineBtn.remove();

        // --- DESKTOP: Handle different advert types ---
        if (isCarAdvert) {
            // Car advert: Direct inline modification
            // Store original content
            const originalContent = carSellerElement.innerHTML;

            // Convert span to inline-flex and add button
            carSellerElement.style.display = 'inline-flex';
            carSellerElement.style.alignItems = 'center';
            carSellerElement.style.gap = '8px';

            // Create the button
            const btn = document.createElement('button');
            btn.className = 'cleanplaats-blacklist-btn cleanplaats-inline-btn';
            btn.textContent = 'Verkoper verbergen';
            btn.type = 'button';
            btn.tabIndex = 0;
            btn.style.marginLeft = '8px';

            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                addSellerToBlacklist(sellerName);
            });

            // Add button to the seller name span
            carSellerElement.appendChild(btn);
        } else {
            // Normal advert: original logic
            // Create the button row
            const btnRow = document.createElement('div');
            btnRow.className = 'cleanplaats-blacklist-btn-row';

            // Create the button
            const btn = document.createElement('button');
            btn.className = 'cleanplaats-blacklist-btn';
            btn.textContent = 'Verkoper verbergen';
            btn.type = 'button';
            btn.tabIndex = 0;

            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                addSellerToBlacklist(sellerName);
            });

            btnRow.appendChild(btn);

            // Insert the button row AFTER the seller name container (not inside the link!)
            if (sellerElement.parentNode) {
                sellerElement.parentNode.insertBefore(btnRow, sellerElement.nextSibling);
            }
        }
    });
}

/**
 * Show the blacklist management modal
 */
function showBlacklistModal() {
    const modal = document.getElementById('cleanplaats-blacklist-modal');
    if (!modal) return;

    // Close the terms modal if it's open
    const termsModal = document.getElementById('cleanplaats-terms-modal');
    if (termsModal) {
        termsModal.style.display = 'none';
    }

    // Toggle modal visibility
    if (modal.style.display === 'block') {
        modal.style.display = 'none';
        return;
    }

    const sellers = CLEANPLAATS.settings.blacklistedSellers;

    modal.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-modal-content">
            <h4>Verborgen verkopers</h4>
            <ul id="cleanplaats-blacklist-list">
                ${sellers.length === 0 ? '<li><em>Geen verkopers toegevoegd</em></li>' : sellers.map(seller => `
                    <li>
                        <span>${seller}</span>
                        <button class="cleanplaats-unblacklist-btn" data-seller="${seller}">Verborgen</button>
                    </li>
                `).join('')}
            </ul>
            <div class="cleanplaats-terms-input-row">
                <input type="text" id="cleanplaats-seller-input" class="cleanplaats-term-input" placeholder="bijv. Catawiki">
                <button id="cleanplaats-add-seller" class="cleanplaats-add-term-btn">Toevoegen</button>
            </div>
            <div class="cleanplaats-input-help">Wil je meerdere namen tegelijk toevoegen? Scheid ze dan met komma's of puntkomma's.</div>
            <button id="cleanplaats-blacklist-close" style="margin-top:10px;">Sluiten</button>
        </div>
    `);
    modal.style.display = 'block';

    // Close modal
    document.getElementById('cleanplaats-blacklist-close').onclick = () => {
        modal.style.display = 'none';
    };

    const addSeller = () => {
        const input = document.getElementById('cleanplaats-seller-input');
        const sellerNames = input.value
            .split(/[;,]+/)
            .map(name => name.trim())
            .filter(Boolean);

        if (sellerNames.length === 0) return;

        addSellersToBlacklist(sellerNames);
        input.value = '';
    };

    document.getElementById('cleanplaats-add-seller').onclick = addSeller;

    document.getElementById('cleanplaats-seller-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            addSeller();
        }
    });

    // Add hover effect and unblacklist functionality
    setupBlacklistModalButtons();
}

/**
 * Update the blacklist modal dynamically
 */
function updateBlacklistModal() {
    const modal = document.getElementById('cleanplaats-blacklist-modal');
    if (!modal || modal.style.display === 'none') return;

    const sellers = CLEANPLAATS.settings.blacklistedSellers;
    const list = document.getElementById('cleanplaats-blacklist-list');

    if (list) {
        list.innerHTML = DOMPurify.sanitize(
            sellers.length === 0
                ? '<li><em>Geen verkopers toegevoegd</em></li>'
                : sellers.map(seller => `
                    <li>
                        <span>${seller}</span>
                        <button class="cleanplaats-unblacklist-btn" data-seller="${seller}">Verborgen</button>
                    </li>
                `).join('')
        );

        setupBlacklistModalButtons();
    }
}

/**
 * Set up hover effects and unblacklist functionality for modal buttons
 */
function setupBlacklistModalButtons() {
    document.querySelectorAll('.cleanplaats-unblacklist-btn').forEach(btn => {
        btn.onmouseover = () => {
            btn.style.background = 'green';
            btn.textContent = 'Opheffen';
        };
        btn.onmouseout = () => {
            btn.style.background = '#ff4d4d';
            btn.textContent = 'Verborgen';
        };
        btn.style.background = '#ff4d4d';
        btn.style.color = 'white';
        btn.onclick = () => {
            const sellerName = btn.dataset.seller;
            showUnblacklistToast(sellerName);
            removeSellerFromBlacklist(sellerName);
        };
    });
}

/**
 * Show a toast notification for blacklisting a term
 */
function showBlacklistTermToast(term) {
    const toast = document.createElement('div');
    toast.className = 'cleanplaats-blacklist-toast';
    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-toast-content">
            <span class="cleanplaats-toast-icon">🔎</span>
            <div class="cleanplaats-toast-message">
                <strong>'${term}' verborgen</strong>
                <span>Alle advertenties met de term '${term}' zijn nu verborgen.</span>
            </div>
        </div>
    `);
    document.body.appendChild(toast);
    setTimeout(() => { requestAnimationFrame(() => toast.classList.add('visible')); }, 50);
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Show a toast notification for unblacklisting a term
 */
function showUnblacklistTermToast(term) {
    const toast = document.createElement('div');
    toast.className = 'cleanplaats-blacklist-toast';
    toast.innerHTML = DOMPurify.sanitize(`
        <div class="cleanplaats-blacklist-toast-content">
            <span class="cleanplaats-toast-icon">🔎</span>
            <div class="cleanplaats-toast-message">
                <strong>'${term}' niet meer verborgen</strong>
                <span>Advertenties met de term '${term}' worden weer getoond.</span>
            </div>
        </div>
    `);
    document.body.appendChild(toast);
    setTimeout(() => { requestAnimationFrame(() => toast.classList.add('visible')); }, 50);
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/* ======================
 OBSERVATION & NAVIGATION
 ====================== */

/**
 * Add keyboard navigation for carousel images
 */
let keyboardNavigationSetup = false; // Flag to track if keyboard navigation is already set up

// --- Keyboard navigation for carousel images is now handled natively by Marktplaats.\n// The following function and its invocations are commented out to prevent double-advancing/skipping images.\n// If Marktplaats removes their native support in the future, you can re-enable this code.\n/*\nfunction setupKeyboardNavigation() {\n    if (keyboardNavigationSetup) {\n        // Remove the existing event listener\n        document.removeEventListener('keydown', keyboardNavigationHandler);\n    }\n\n    // Define the event listener function\n    keyboardNavigationHandler = function(event) {\n        if (document.querySelector('.Carousel-navigationContainer')) {\n            let nextButton = document.querySelector('.Carousel-navigationContainer button[aria-label="Volgende foto"]');\n            let prevButton = document.querySelector('.Carousel-navigationContainer button[aria-label="Vorige foto"]');\n\n            if (event.key === 'ArrowRight' && nextButton) {\n                event.preventDefault(); // Prevent default arrow key behavior\n                nextButton.focus(); // Focus the button\n                nextButton.click(); // Trigger the click\n            } else if (event.key === 'ArrowLeft' && prevButton) {\n                event.preventDefault(); // Prevent default arrow key behavior\n                prevButton.focus(); // Focus the button\n                prevButton.click(); // Trigger the click\n            }\n        }\n    };\n\n    document.addEventListener('keydown', keyboardNavigationHandler);\n    keyboardNavigationSetup = true; // Set the flag to true after setting up\n}\n*/\n

/**
 * Perform cleanup and check for empty page
 */
function performCleanupAndCheckForEmptyPage() {
    // Remove the notification on navigation
    const existingNotification = document.getElementById('cleanplaats-empty-notification');
    if (existingNotification) {
        existingNotification.remove();
        notificationVisible = false;
    }

    // Clear the bubble notification
    clearBubbleNotification();

    // Immediately reapply filters when new content loads
    const checkContentLoaded = setInterval(() => {
        if (document.querySelector('.hz-Listing') || document.querySelector('#adsense-container')) {
            clearInterval(checkContentLoaded);
            console.log('Cleanplaats: Running cleanup after navigation');
            performCleanup();
            injectBlacklistButtons();

            // Delay the check for empty page to ensure DOM is fully updated
            setTimeout(checkForEmptyPage, 500);
        }
    }, 100);
}

/**
 * Set up a combined mutation observer for DOM and URL changes
 */
function setupObservers() {
    let lastUrl = location.href;

    // Disconnect any existing observers
    if (CLEANPLAATS.observers.mutation) {
        CLEANPLAATS.observers.mutation.disconnect();
    }

    const observer = new MutationObserver(mutations => {
        // Check for URL changes
        if (lastUrl !== location.href) {
            console.log('Cleanplaats: URL changed from', lastUrl, 'to', location.href);
            lastUrl = location.href;
            performCleanupAndCheckForEmptyPage();
        }

        let shouldCleanup = false;

        // Check if any relevant elements were added
        for (const mutation of mutations) {
            if (mutation.type === 'childList' && mutation.addedNodes.length) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        // Check if any ads or listings were added
                        if (
                            node.classList?.contains('hz-Listing') ||
                            node.querySelector?.('.hz-Listing') ||
                            node.id?.includes('ad') ||
                            node.classList?.contains('hz-Banner') ||
                            node.querySelector?.('[data-google-query-id]') ||
                            node.classList?.contains('hz-FeedBannerBlock') ||
                            node.classList?.contains('Banners-bannerFeedItem') ||
                            node.id === 'banner-top-dt-container' ||
                            node.querySelector?.('#banner-top-dt, #banner-top-dt-container')
                        ) {
                            shouldCleanup = true;
                            break;
                        }
                    }
                }
            }

            if (mutation.type === 'attributes') {
                const target = mutation.target;
                if (
                    target?.classList?.contains('hz-FeedBannerBlock') ||
                    target?.classList?.contains('Banners-bannerFeedItem') ||
                    target?.id === 'banner-right-container' ||
                    target?.id === 'banner-top-dt-container'
                ) {
                    shouldCleanup = true;
                }
            }

            if (shouldCleanup) break;
        }

        // Run cleanup if needed, but don't reset stats since we want to accumulate
        if (shouldCleanup) {
            performCleanup();
            injectBlacklistButtons();
        }
    });

    // Start observing the entire document
    observer.observe(document, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style', 'hidden', 'aria-hidden']
    });

    // Store the observer
    CLEANPLAATS.observers.mutation = observer;
}

/**
 * Unified function to handle navigation events
 */
function handleNavigation() {
    // Wake up background script on navigation
    wakeUpBackground();
    window.dispatchEvent(new Event('navigation'));
}

/**
 * Set up event listeners for SPA navigation
 */
function setupNavigationDetection() {
    // Listen for popstate event
    window.addEventListener('popstate', handleNavigation);

    // Monkey patch history methods to detect SPA navigation
    const originalPushState = history.pushState;
    history.pushState = function () {
        originalPushState.apply(this, arguments);
    };

    const originalReplaceState = history.replaceState;
    history.replaceState = function () {
        originalReplaceState.apply(this, arguments);
    };

    // Additional event listeners for Marktplaats-specific navigation
    document.addEventListener('click', (e) => {
        // Check if clicked element is a navigation link
        const link = e.target.closest('a[href]');
        if (link && link.hostname === window.location.hostname) {
            // Small delay to let the navigation occur
            setTimeout(() => handleNavigation(), 100);
        }
    });
}

/**
 * Set up all observers
 */
function setupAllObservers() {
    setupObservers();
    setupNavigationDetection();
}

/**
 * Check if we're currently on a search results page
 * Uses the same logic as the background script's matchUrl function
 */
function isSearchResultsPage() {
    const url = window.location.href;
    return url.includes('marktplaats.nl/l/') ||
        url.includes('marktplaats.nl/q/') ||
        url.includes('2dehands.be/l/') ||
        url.includes('2dehands.be/q/');
}

function setupResultsDropdownListener() {
    const dropdown = document.getElementById('cleanplaats-results-dropdown');
    if (!dropdown) return;

    dropdown.addEventListener('change', (e) => {
        const value = parseInt(e.target.value, 10);

        CLEANPLAATS.settings.resultsPerPage = value;

        // Wake up background script before saving settings
        wakeUpBackground();

        // Save settings - this will trigger the background script to update
        saveSettings().then(() => {
            // Show feedback
            const header = document.querySelector('.cleanplaats-header');
            if (header) {
                const feedback = document.createElement('div');
                feedback.className = 'cleanplaats-feedback';
                feedback.textContent = '✓';
                header.querySelectorAll('.cleanplaats-feedback').forEach(el => el.remove());
                header.appendChild(feedback);
                requestAnimationFrame(() => feedback.classList.add('cleanplaats-feedback-show'));
                setTimeout(() => feedback.remove(), 1500);
            }

            // Only reload if we're on a search results page
            if (isSearchResultsPage()) {
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
        });
    });
}

function setupSortDropdownListener() {
    const dropdown = document.getElementById('cleanplaats-sort-dropdown');
    if (!dropdown) return;

    dropdown.addEventListener('change', (e) => {
        const value = e.target.value;

        CLEANPLAATS.settings.defaultSortMode = value;
        CLEANPLAATS.settings.sortPreferenceSource = 'cleanplaats';

        // Wake up background script before saving settings
        wakeUpBackground();

        // Save settings - this will trigger the background script to update
        saveSettings().then(() => {
            // Show feedback
            const header = document.querySelector('.cleanplaats-header');
            if (header) {
                const feedback = document.createElement('div');
                feedback.className = 'cleanplaats-feedback';
                feedback.textContent = '✓';
                header.querySelectorAll('.cleanplaats-feedback').forEach(el => el.remove());
                header.appendChild(feedback);
                requestAnimationFrame(() => feedback.classList.add('cleanplaats-feedback-show'));
                setTimeout(() => feedback.remove(), 1500);
            }

            // Only reload if we're on a search results page
            if (isSearchResultsPage()) {
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
        });
    });
}
